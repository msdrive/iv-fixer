











<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity Ventures</title>
	<link rel="icon" href="assets/img/favi.png" type="image" sizes="16x16">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Acme">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amiko">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
 

<nav class="navbar navbar-light  sticky-top bg-secondary">
    <div class="container-fluid"><a href="index.php" class="navbar-brand"><img src="assets/img/logo.png" class="img-fluid logo" href="#" /></a><img src="assets/img/fixerlogo.png" class="img-fluid logo fixer-logo"><button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggler"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        <div
            class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav ml-auto">
                <li role="presentation" class="nav-item"><a href="index.php" class="nav-link ">Home</a></li>
                <li role="presentation" class="nav-item"><a href="services.php" class="nav-link ">Services</a></li>
                <li role="presentation" class="nav-item"><a href="product.php" class="nav-link active">Product</a></li>
                <li role="presentation" class="nav-item"><a href="about.php" class="nav-link ">About us</a></li>
                <li role="presentation" class="nav-item"><a href="blog.php" class="nav-link ">Blog</a></li>
                <li role="presentation" class="nav-item"><a href="contact.php" class="nav-link ">Contact us</a></li>
            </ul>
    </div>
    </div>
</nav>    <section id="product" class="sect_pad">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h4 class="text-uppercase text-center">Products</h4>
                    <div class="centr"></div>
                    <section>
                        <div class="container">
                            <div class="filtr-controls"><span class="active" data-filter="all">all</span>
							 							<span data-filter="58">NYLON FRAME FIXING ANCHORS</span>
														<span data-filter="56">SELF DRILLING SCREWS</span>
														<span data-filter="57">SELF TAPPING SCREWS</span>
														<span data-filter="59">PLASTIC ACCESSORIES</span>
														<span data-filter="60">UPVC HARDWARE</span>
														<span data-filter="61">WOOL PILE WEATHERSTRIP</span>
														<span data-filter="62">RUBBER GASKETS</span>
														</div>
                            <div class="row filtr-container">
							                                 <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="58">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/c11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more35">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form35">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Nylon Frame Fixing Anchor</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="56">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/s1.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more36">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form36">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Countersunk Head Self Drilling Screw</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="56">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/p31.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more38">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form38">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Stainless Steel Self Drilling Screw - SS</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="56">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/p51.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more39">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form39">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Pan Head Phillips Self Drilling Screw - SS</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="57">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/csk1.png">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more40">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form40">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Countersunk Head Self Tapping Screw</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="57">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/selftapping1.png">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more82">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form82">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Pan Head Self Tapping Screw</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/d11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more42">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form42">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Drain Hole Cover</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/d21.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more43">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form43">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Drilling Screw Cap</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/d31.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more44">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form44">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Dust Arrester</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/d41.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more45">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form45">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Fixed Louver</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/d61.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more47">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form47">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Plastic Jump Arrester</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/d71.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more48">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form48">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Plastic U-Packer</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/d81.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more49">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form49">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Runner Block</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="59">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/flat-packer1.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more79">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form79">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Flat Packer</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/e11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more50">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form50">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Adjustable Double Roller with Groove</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/f11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more51">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form51">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Nylon Single Roller With Groove</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/g11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more52">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form52">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Single Roller Flat</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/h11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more53">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form53">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Casement Handle</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/i11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more54">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form54">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Friction Hinges</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/j11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more55">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form55">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4"> Mesh Roller</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/k11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more56">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form56">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">UPVC Window Touch Lock</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/popup-1.jpeg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more73">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form73">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">POP UP Handle</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/ROLLER-1.png">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more74">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form74">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">Double Roller Adjustable for Doors</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/L-bracket-1.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more76">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form76">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">L Bracket / Clamp (3 Models) - 12 W x 40 L </h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="60">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more77">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form77">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">L Bracket / Clamp (3 Models) 25 W X 60 L </h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="61">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/l11.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more57">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form57">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">WOOL PILE WEATHERSTRIP</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="62">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/thermoplastic-elastomer-gaskets-500x500 (1).jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more62">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form62">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">TPE Gaskets</h2>
                                </div>
								                                <div class="col-sm-6 col-md-4 col-lg-3 filtr-item" data-category="62">
                                    <div class="hovereffect"><img class="img-fluid" src="upload/epdm1.jpg">
                                        <div class="overlay">
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#know-more63">DesCRIPTION</a></div>
                                            <div><a href="#" class="info" data-toggle="modal" data-target="#enquiry-form63">Enquiry</a></div>
                                        </div>
                                    </div><h2 class="prod-title py-4">EPDM Flat Gaskets</h2>
                                </div>
								 
                            </div>
							                            <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form35">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Nylon Frame Fixing Anchor&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=35&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more35">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Nylon Frame Fixing Anchor</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/c11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Nylon Frame Fixing Anchor</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Nylon Frame Fixing Anchor are pre-assembled through fixing, a light duty nail expanding for solid masonry and hollow wall constructions. The design of the expansion nail used in the Nylon Frame Fixing Anchor is such that it can be removed if need be.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=35" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form36">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Countersunk Head Self Drilling Screw&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=36&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more36">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Countersunk Head Self Drilling Screw</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/s1.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Countersunk Head Self Drilling Screw</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Countersunk Head Self Drilling Screw enable drilling without first creating a pilot hole. These screws are usually used to join materials like sheet metal.There are two distinct types of metal used in different parts of the fastener. Usually one type of metal is used for the head and shaft, while a harder metal is used at the point or drilling tip.The most common material used in these screws, is predominantly iron mixed with carbon. It offers the highest strength compared to other metals and elements.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=36" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form38">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Stainless Steel Self Drilling Screw - SS&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=38&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more38">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Stainless Steel Self Drilling Screw - SS</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/p31.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Stainless Steel Self Drilling Screw - SS</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Stainless Steel Self Drilling Screw is an iron based material with a minimum of 10.5% chromium. This material is known for its corrosion resistance and has varying strengths depending on the amount of chromium and nickel alloy. The chromium forms a protective layer when exposed to oxygen, keeping the steel underneath from corroding. There are over 150 grades of this material with the 304 and 316 series being the most common.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=38" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form39">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Pan Head Phillips Self Drilling Screw - SS&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=39&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more39">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Pan Head Phillips Self Drilling Screw - SS</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/p51.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Pan Head Phillips Self Drilling Screw - SS</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Pan Head Phillips Self Drilling Screw are easy to install and designed to drill, tap and seal. 																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=39" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form40">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Countersunk Head Self Tapping Screw&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=40&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more40">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Countersunk Head Self Tapping Screw</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/csk1.png">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Countersunk Head Self Tapping Screw</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Countersunk Head Self Tapping Screw is a screw that can tap its own hole as it is driven into the material. For hard substrates such as metal or hard plastics, the self-tapping ability is often created by cutting a gap in the continuity of the thread on the screw, generating a flute and cutting edge similar to those on a tap. These screws are manufactured to meet all recognised industry standards and performance criteria. A variety of sizes for any job large or small as well as larger pack sizes for those bigger projects.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=40" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form82">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Pan Head Self Tapping Screw&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=82&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more82">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Pan Head Self Tapping Screw</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/selftapping1.png">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Pan Head Self Tapping Screw</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Pan Head Self Tapping Screw is a screw that can tap its own hole as it is driven into the material. For hard substrates such as metal or hard plastics, the self-tapping ability is often created by cutting a gap in the continuity of the thread on the screw, generating a flute and cutting edge similar to those on a tap. These screws are manufactured to meet all recognised industry standards and performance criteria. A variety of sizes for any job large or small as well as larger pack sizes for those bigger projects.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=82" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form42">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Drain Hole Cover&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=42&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more42">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Drain Hole Cover</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/d11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Drain Hole Cover</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used to allow the water to drain out from within the frame, Snaps into pre-existing slots. This prevents bugs, debris and air from entering.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=42" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form43">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Drilling Screw Cap&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=43&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more43">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Drilling Screw Cap</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/d21.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Drilling Screw Cap</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used to cover the hole made to fix the frame fixing Anchor after Installation.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=43" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form44">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Dust Arrester&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=44&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more44">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Dust Arrester</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/d31.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Dust Arrester</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in UPVC Doors and windows, made of High quality Virgin Plastic																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=44" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form45">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Fixed Louver&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=45&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more45">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Fixed Louver</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/d41.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Fixed Louver</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in UPVC ventilators made of high quality virgin plastic designed to hold the glass at an inclined angle to admit light and air.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=45" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form47">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Plastic Jump Arrester&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=47&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more47">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Plastic Jump Arrester</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/d61.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Plastic Jump Arrester</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in assembly of UPVC doors and window, made of high quality virgin plastic.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=47" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form48">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Plastic U-Packer&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=48&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more48">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Plastic U-Packer</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/d71.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Plastic U-Packer</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Plastic U-Packers is used in Doors and Windows. It is resistant to weather changes and waterproof. Also used for partitions and door linings.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=48" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form49">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Runner Block&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=49&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more49">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Runner Block</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/d81.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Runner Block</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in the Assembly of UPVC Doors and windows, made of High quality virgin plastic.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=49" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form79">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Flat Packer&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=79&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more79">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Flat Packer</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/flat-packer1.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Flat Packer</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in the assembly of UPVC doors and windows, made of high quality virgin plastic.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=79" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form50">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Adjustable Double Roller with Groove&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=50&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more50">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Adjustable Double Roller with Groove</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/e11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Adjustable Double Roller with Groove</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in assembly of UPVC sliding windows, our rollers are made of high quality material offering high performance and durability.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=50" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form51">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Nylon Single Roller With Groove&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=51&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more51">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Nylon Single Roller With Groove</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/f11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Nylon Single Roller With Groove</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in assembly of UPVC sliding windows, our rollers are made of high quality material offering high performance and durability.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=51" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form52">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Single Roller Flat&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=52&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more52">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Single Roller Flat</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/g11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Single Roller Flat</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in assembly of UPVC sliding doors, our rollers are made of high quality material offering high performance and durability.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=52" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form53">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Casement Handle&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=53&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more53">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Casement Handle</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/h11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Casement Handle</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in UPVC openable window and doors,  our casement handles are meant for higher performance and durability.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=53" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form54">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Friction Hinges&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=54&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more54">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Friction Hinges</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/i11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Friction Hinges</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in assembly of UPVC openable window. Our friction hinges are made of high quality stainless steel.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=54" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form55">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span> Mesh Roller&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=55&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more55">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span> Mesh Roller</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/j11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title"> Mesh Roller</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Used in the assembly of bug screening for UPVC windows made of high quality material.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=55" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form56">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>UPVC Window Touch Lock&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=56&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more56">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>UPVC Window Touch Lock</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/k11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">UPVC Window Touch Lock</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																UPVC Window Touch Lock is single point handle Made of high quality Aluminium Diecasting Fits all uPVC profile systems. This Touch Lock is specially designed for the sliding windows and sliding doors which is also highly acclaimed and liked by the clients, due to the hard wearing construction and durability.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=56" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form73">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>POP UP Handle&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=73&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more73">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>POP UP Handle</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/popup-1.jpeg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">POP UP Handle</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																This handle is used in UPVC sliding windows/Doors, made of high quality material. Our handles are accredited for features like high strength, durability, light weight, heat and temperature resistance etc.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=73" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form74">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Double Roller Adjustable for Doors&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=74&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more74">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>Double Roller Adjustable for Doors</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/ROLLER-1.png">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">Double Roller Adjustable for Doors</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=74" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form76">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>L Bracket / Clamp (3 Models) - 12 W x 40 L &nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=76&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more76">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>L Bracket / Clamp (3 Models) - 12 W x 40 L </span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/L-bracket-1.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">L Bracket / Clamp (3 Models) - 12 W x 40 L </h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=76" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form77">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>L Bracket / Clamp (3 Models) 25 W X 60 L &nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=77&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more77">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>L Bracket / Clamp (3 Models) 25 W X 60 L </span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">L Bracket / Clamp (3 Models) 25 W X 60 L </h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=77" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form57">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>WOOL PILE WEATHERSTRIP&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=57&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more57">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>WOOL PILE WEATHERSTRIP</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/l11.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">WOOL PILE WEATHERSTRIP</h4>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Wool Pile Weatherstrip are used to seal the openings in UPVC Doors and Windows. This is to prevent rain water from entering inside. This also will keep interior air in, thus saving energy on heating and air conditioning. These wool piles are designed as per market standards. The pile is Siliconised and UV treated multifilament fibre. It is water repellent and has excellent resistance and recovery property 																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=57" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form62">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>TPE Gaskets&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=62&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more62">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>TPE Gaskets</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/thermoplastic-elastomer-gaskets-500x500 (1).jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">TPE Gaskets</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																Thermoplastic elastomers (TPE), sometimes referred to as thermoplastic rubbers, are a class of copolymers or a physical mix of polymers (usually a plastic and a rubber) which consist of materials with both thermoplastic and elastomeric properties.TPEs (thermoplastic elastomers) have the properties and performance of rubber, but are processed like plastic. TPEs are flexible materials that can be repeatedly stretched to at least twice their original length at room temperature and return to the approximate length of the original shape upon stress release.																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=62" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                             <div class="modal fade" role="dialog" tabindex="-1" id="enquiry-form63">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>EPDM Flat Gaskets&nbsp;</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" method="post" action="product_mail.php?id=63&page=product">
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Name</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-md-0"><input class="form-control" type="text" required="" name="name" id="name"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Email</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6 offset-sm-0"><input class="form-control" type="email" name="email" id="email"></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Contact number</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><input class="form-control" name="cnumber" id="cnumber" type="tel" required=""></div>
                                                </div>
                                                <div class="form-row enq-form">
                                                    <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-sm-1 offset-md-1 offset-xl-1"><label class="col-form-label">Message</label></div>
                                                    <div class="col-12 col-sm-6 col-md-6 col-xl-6"><textarea class="form-control" name="comments" id="comments" required></textarea></div>
                                                </div>
                                                <div class="form-row text-center">
                                                    <div class="col-12 col-sm-12"><button class="btn btn-light enq-btn" type="reset">Clear</button><button class="btn btn-light enq-btn submit" type="submit">Submit</button></div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" role="dialog" tabindex="-1" id="know-more63">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <div class="enq-head enq-item"><span>EPDM Flat Gaskets</span></div><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                        <div class="modal-body">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                                        <div class="box"><img class="img-fluid" src="upload/epdm1.jpg">
                                                            <div class="box-heading py-2">
                                                                <h4 class="title">EPDM Flat Gaskets</h4>
																																<span class="post">&nbsp;Brand: Fixer</span>
																																</div>
                                                            <div class="boxContent">
                                                                <p class="text-center description">
																																EPDM rubber is one of the most popular, versatile materials available. EPDM is known for its excellent resistance to heat, ozone, sunlight and ageing. Its distinctive ability to stabilise colour and resist harsh weather conditions makes it an ideal choice for outdoor applications. EPDM features excellent resistance to water, steam, alkalis, acids and oxidants. It is also sulphur and peroxide curable																</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer align-middle text-center boxContent"><a href="p1.php?id=63" class="read">Read more<i class="fa fa-angle-right"></i></a></div>
                                    </div>
                                </div>
                            </div>
							
							                         </div>
                    </section>
                </div>
            </div>
        </div>
    </section>
     <section id="contact" class="sect_pad">
        <div class="container">
            <h2>Feel Free To Ask Anything</h2>
            <h4 class="text-uppercase text-center">Contact us&nbsp;</h4>
            <div class="centr"></div>
            <p class="text-center"><strong>Simply leave us your contact details and we'll get back to you<br><br></p>
            <div class="row">
                <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-home"></i>
                        <h5>ADDRESS</h5>
                        <p>114G&amp;H, Mahatma Gandhi Road, <br>TASS Industrial Estate, Ambathur, Chennai-98 <br></p>
                    </div>
                </div>
                <div class="col-sm-5 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-envelope-o"></i>
                        <h5>MAIL</h5>
                        <a href="mailto:info@infinityventures.org">
                            <p>info@infinityventures.org<br></p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-5 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-phone"></i>
                        <h5>Phone</h5>
                        <p>9677040599<br></p>
                    </div>
                </div>
            </div>
            <div>
				<form class="form-horizontal" method="post" action="contact_mail.php">
                <div class="row">
				 
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-lg-0 offset-xl-0">
                       
                        <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="text" placeholder="Name" required id="name" name="name"></div>
                                </div>
                         </fieldset>

                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="email" required="true" placeholder="Email" inputmode="email" name="email"></div>
                                </div>
                            </fieldset>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="text" required="true" placeholder="Phone Number" maxlength="10" minlength="10" inputmode="tel" name="number"></div>
                                </div>
                            </fieldset>
                    </div>
					
                </div>
                <div class="row form_msg">
                    <div class="col-lg-12 col-xl-12 offset-lg-0 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div class="text-center"><textarea class="form-control" rows="4" required="true" id="text-area" name="message" placeholder="Message"></textarea></div>
                                </div>
                            </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-5 offset-lg-4"><button class="btn btn-primary btn-hero" type="submit" value="submit">Send Message</button></div>
                </div>
				</form>
            </div>
        </div>
    </section>
    <div class="footer-bottom">
        <div class="container">
            <p class="text-center">©&nbsp;<a href="http://techtilttechnologies.com/" target="_blank">TechTilt Technologies.&nbsp;</a><span>All Rights Reserved</span></p>
        </div>
    </div>
    	<script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/product-filter.js"></script>
    <script src="assets/js/Animated-Number-element.js"></script>
</body>

</html>