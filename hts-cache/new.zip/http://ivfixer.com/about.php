<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Infinity Ventures</title>
	<link rel="icon" href="assets/img/favi.png" type="image" sizes="16x16">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Acme">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amiko">
    <link rel="stylesheet" href="assets/css/styles.css">
<link rel="icon" href="favicon.ico" type="image/x-icon" />

</head>

<body>
   
    

<nav class="navbar navbar-light  sticky-top bg-secondary">
    <div class="container-fluid"><a href="index.php" class="navbar-brand"><img src="assets/img/logo.png" class="img-fluid logo" href="#" /></a><img src="assets/img/fixerlogo.png" class="img-fluid logo fixer-logo"><button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggler"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        <div
            class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav ml-auto">
                <li role="presentation" class="nav-item"><a href="index.php" class="nav-link ">Home</a></li>
                <li role="presentation" class="nav-item"><a href="services.php" class="nav-link ">Services</a></li>
                <li role="presentation" class="nav-item"><a href="product.php" class="nav-link ">Product</a></li>
                <li role="presentation" class="nav-item"><a href="about.php" class="nav-link active">About us</a></li>
                <li role="presentation" class="nav-item"><a href="blog.php" class="nav-link ">Blog</a></li>
                <li role="presentation" class="nav-item"><a href="contact.php" class="nav-link ">Contact us</a></li>
            </ul>
    </div>
    </div>
</nav>   
    <section id="about" class="sect-padding">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-4 col-lg-4 align-self-center">
					 <figure class="figure text-center" id="container">
							<figure class="figure" id="slideshow">
								<img class="img-fluid figure-img" src="assets/img/abt.jpg">
								<img class="img-fluid figure-img" src="assets/img/abt-1.jpg">
								<img class="img-fluid figure-img" src="assets/img/abt-3.jpg">
								<img class="img-fluid figure-img" src="assets/img/abt-4.jpg">
								<img class="img-fluid figure-img" src="assets/img/abt-6.jpg">	
								<img class="img-fluid figure-img" src="assets/img/abt-2.png">								
						</figure>
					</figure>
				</div>
                <div class="col-md-8 col-lg-6 col-xl-6 offset-lg-1">
                    <h4>About us</h4>
                    <p><br>Our Journey of Infinite Possibilities started in the year 2014. With cumulative experience and accumulated knowledge of more than 25 years in various spectrum of corporate and industrial world including  Aviation, Power, Wood working, Advertising, Industrial/Retail Storage Solutions, Automotive, Construction etc., we opened the Doors of Infinity Ventures dedicated to serve the UPVC world.<br><br>We wanted to invest our knowledge and experience in a growing and upcoming field and while searching for the right spectrum we found the then budding UPVC Doors and Windows fabrication industry that needs lot of speciality type Screws and Fasteners for making the Doors and Windows.
Thus Infinity Ventures gave birth to FIXER,
Yes - FIXER is our first child. As name sounds our FIXER Range of Speciality Screws are used to fix (assemble) the UPVC doors and windows.
<br><br></p>
                    <div class="text-center"></div>
                </div>
            </div>
            <div class="row abt1">
                <div class="col-xl-8 offset-xl-2 wvr">
                    
                    <div></div>
                </div>
                <div class="col-xl-4 offset-xl-2 wvr">
                    <h5>Our Company</h5>
                     <p>At Infinity Ventures We passionately support our customers. Satisfying our customers is not enough. We want to inspire them. First and foremost, a customer-oriented sales approach, the service idea it represents and top-notch quality are characteristic of the products and services of Infinity Ventures. As a consequence, we continuously try to find new solutions to support our customers’ business even better and we try to achieve it by a strong brand policy, future-oriented product strategy, closeness to the customer etc.</p>
                </div>
                <div class="col-xl-4 offset-xl-1">
                    <h5>What we Do?</h5>
					<p>We fully understand the importance of our product being used in Doors and Windows which is going to safe guard millions of houses and we don’t want to compromise on anything. We have stringent quality control measures with our contract manufacturers worldwide.
Each and every product of FIXER is carefully crafted to last long. We take utmost care in providing highest degree of satisfaction to our customers. One of our most important principles is to achieve perfection in everything we do.
</p>
                </div>
            </div>
        </div>
    </section>
    <div class="counts sect_pad">
        <div class="container">
            <div class="row">
                <!--<div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                    <div class="count_center"><i class="fa fa-heart"></i>
                        <div class="counts1"><span class="count">253</span><span class="count_text">Happy Customers</span></div>
                    </div>
                </div> -->
                <div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-4 offset-lg-4 offset-md-4 offset-sm-4">
                    <div class="count_center"><i class="fa fa-heart"></i>
                        <div class="counts1"><span class="count">150 <span>+</span></span><span class="count_text">Happy Customers</span></div>
                    </div>
                </div>
                <!--<div class="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                    <div class="count_center"><i class="fa fa-heart"></i>
                        <div class="counts1"><span class="count">253</span><span class="count_text">Happy Customers</span></div>
                    </div>
                </div>-->
            </div>
        </div>
    </div>
    
    <section id="contact" class="sect_pad">
        <div class="container">
            <h2>Feel Free To Ask Anything</h2>
            <h4 class="text-uppercase text-center">Contact us&nbsp;</h4>
            <div class="centr"></div>
            <p class="text-center"><strong>Simply leave us your contact details and we'll get back to you<br><br></p>
            <div class="row">
                <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-home"></i>
                        <h5>ADDRESS</h5>
                        <p>114G&amp;H, Mahatma Gandhi Road, <br>TASS Industrial Estate, Ambathur, Chennai-98 <br></p>
                    </div>
                </div>
                <div class="col-sm-5 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-envelope-o"></i>
                        <h5>MAIL</h5>
                        <a href="mailto:info@infinityventures.org">
                            <p>info@infinityventures.org<br></p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-5 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-phone"></i>
                        <h5>Phone</h5>
                        <p>9677040599<br></p>
                    </div>
                </div>
            </div>
            <div>
				<form class="form-horizontal" method="post" action="contact_mail.php">
                <div class="row">
				 
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-lg-0 offset-xl-0">
                       
                        <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="text" placeholder="Name" required id="name" name="name"></div>
                                </div>
                         </fieldset>

                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="email" required="true" placeholder="Email" inputmode="email" name="email"></div>
                                </div>
                            </fieldset>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="text" required="true" placeholder="Phone Number" maxlength="10" minlength="10" inputmode="tel" name="number"></div>
                                </div>
                            </fieldset>
                    </div>
					
                </div>
                <div class="row form_msg">
                    <div class="col-lg-12 col-xl-12 offset-lg-0 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div class="text-center"><textarea class="form-control" rows="4" required="true" id="text-area" name="message" placeholder="Message"></textarea></div>
                                </div>
                            </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-5 offset-lg-4"><button class="btn btn-primary btn-hero" type="submit" value="submit">Send Message</button></div>
                </div>
				</form>
            </div>
        </div>
    </section>
    <div class="footer-bottom">
        <div class="container">
            <p class="text-center">©&nbsp;<a href="http://techtilttechnologies.com/" target="_blank">TechTilt Technologies.&nbsp;</a><span>All Rights Reserved</span></p>
        </div>
    </div>
        <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/product-filter.js"></script>
    <script src="assets/js/Animated-Number-element.js"></script>
	<script src="assets/js/product-slider.js"></script>
</body>

</html>