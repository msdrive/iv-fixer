<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Infinity Ventures</title>
	<link rel="icon" href="assets/img/favi.png" type="image" sizes="16x16">	
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Acme">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Amiko">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
 

<nav class="navbar navbar-light  sticky-top bg-secondary">
    <div class="container-fluid"><a href="index.php" class="navbar-brand"><img src="assets/img/logo.png" class="img-fluid logo" href="#" /></a><img src="assets/img/fixerlogo.png" class="img-fluid logo fixer-logo"><button data-toggle="collapse" data-target="#navcol-1" class="navbar-toggler"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        <div
            class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav ml-auto">
                <li role="presentation" class="nav-item"><a href="index.php" class="nav-link ">Home</a></li>
                <li role="presentation" class="nav-item"><a href="services.php" class="nav-link ">Services</a></li>
                <li role="presentation" class="nav-item"><a href="product.php" class="nav-link ">Product</a></li>
                <li role="presentation" class="nav-item"><a href="about.php" class="nav-link ">About us</a></li>
                <li role="presentation" class="nav-item"><a href="blog.php" class="nav-link ">Blog</a></li>
                <li role="presentation" class="nav-item"><a href="contact.php" class="nav-link active">Contact us</a></li>
            </ul>
    </div>
    </div>
</nav>    <section class="map sect_pad">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6"><iframe allowfullscreen="" frameborder="0" width="100%" height="400" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCUgAZgaQw9X1_WSQR9GMIao0GuejvBStg&amp;q=TASS+Industrial+Estate%2C+Ambathur%2C&amp;zoom=11"></iframe></div>
                    <div
                        class="col align-self-center hour text-center">
                        <h3>Open Hours</h3>
                        <h4><span>Monday - Friday&nbsp;</span><span>: 9 AM to 9 PM</span></h4>
                        <h4><span>Saturday&nbsp;</span><span>: 9 AM to 5 PM</span></h4>
                        <h4><span>Sunday :&nbsp;</span><span>Closed</span></h4>
                </div>
            </div>
            </div>
     </section>
   <section id="contact" class="sect_pad">
        <div class="container">
            <h2>Feel Free To Ask Anything</h2>
            <h4 class="text-uppercase text-center">Contact us&nbsp;</h4>
            <div class="centr"></div>
            <p class="text-center"><strong>Simply leave us your contact details and we'll get back to you<br><br></p>
            <div class="row">
                <div class="col-sm-6 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-home"></i>
                        <h5>ADDRESS</h5>
                        <p>114G&amp;H, Mahatma Gandhi Road, <br>TASS Industrial Estate, Ambathur, Chennai-98 <br></p>
                    </div>
                </div>
                <div class="col-sm-5 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-envelope-o"></i>
                        <h5>MAIL</h5>
                        <a href="mailto:info@infinityventures.org">
                            <p>info@infinityventures.org<br></p>
                        </a>
                    </div>
                </div>
                <div class="col-sm-5 col-md-4 col-lg-4 col-xl-4">
                    <div class="serv"><i class="fa fa-phone"></i>
                        <h5>Phone</h5>
                        <p>9677040599<br></p>
                    </div>
                </div>
            </div>
            <div>
				<form class="form-horizontal" method="post" action="contact_mail.php">
                <div class="row">
				 
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-lg-0 offset-xl-0">
                       
                        <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="text" placeholder="Name" required id="name" name="name"></div>
                                </div>
                         </fieldset>

                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="email" required="true" placeholder="Email" inputmode="email" name="email"></div>
                                </div>
                            </fieldset>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 col-xl-4 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div><input class="form-control" type="text" required="true" placeholder="Phone Number" maxlength="10" minlength="10" inputmode="tel" name="number"></div>
                                </div>
                            </fieldset>
                    </div>
					
                </div>
                <div class="row form_msg">
                    <div class="col-lg-12 col-xl-12 offset-lg-0 offset-xl-0">
                            <fieldset>
                                <div class="form-group">
                                    <div class="text-center"><textarea class="form-control" rows="4" required="true" id="text-area" name="message" placeholder="Message"></textarea></div>
                                </div>
                            </fieldset>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-5 offset-lg-4"><button class="btn btn-primary btn-hero" type="submit" value="submit">Send Message</button></div>
                </div>
				</form>
            </div>
        </div>
    </section>
    <div class="footer-bottom">
        <div class="container">
            <p class="text-center">©&nbsp;<a href="http://techtilttechnologies.com/" target="_blank">TechTilt Technologies.&nbsp;</a><span>All Rights Reserved</span></p>
        </div>
    </div>
        <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/product-filter.js"></script>
    <script src="assets/js/Animated-Number-element.js"></script>
</body>

</html>